//El usuario introduce un n�mero y si est� entre el 1 y el 5 el valor de la variable X no cambiar�
Algoritmo NumeroEntre1y5Ej14
	//Definici�n de variables
	Definir X Como Logico;
	Definir y Como Entero;
	x = Verdadero;
	//Presentaci�n e introducci�n del n�mero
	Escribir "Introduce un n�mero y si est� entre el 1 y 5 el valor de X no cambiar�";
	Escribir Sin Saltar "N�mero? ";
	Leer y;
	//Procedimiento
	Si y <1 | y>5 Entonces
		x = Falso;
	FinSi
	Escribir "Valor de x: " ,x;
 	
FinAlgoritmo
