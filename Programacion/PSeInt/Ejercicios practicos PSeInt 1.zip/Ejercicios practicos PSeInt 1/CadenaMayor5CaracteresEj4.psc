//El usuario introduce un texto y el programa le dice si su longitud es mayor a 5 car�cteres
Algoritmo CadenaMayor5CaracteresEj4
	//Definici�n de variables
	Definir x Como Caracter;
	Definir y Como Entero;
	
	//Presentaci�n, introducci�n de texto y asignar la longitud a y
	Escribir Sin Saltar "Introduce un texto y yo te dir� si es mayor a 5 car�cteres: ";
	Leer x;
	y = Longitud(x);
	//Procedimiento
	Si y>5 Entonces
		Escribir "La longitud es mayor a 5 car�cteres";
	SiNo
		Escribir "La longitud es menor a 5 car�cteres";
	FinSi
FinAlgoritmo
