//El programa le pregunta si quiere la primera o segunda mitad de su texto o salir del programa, el usuario tiene que elegir y luego introducir su texto y el programa le ense�ar� la opci�n que ha elegido
Algoritmo CadenaMitadEj10
	Definir x,y,z Como Caracter; //Definici�n de variables 
	//x para la opci�n
	//y para el texto
	//z para la subcadena
	
	//Presentaci�n e introducci�n de opci�n y texto
	Escribir "Selecciona una de las siguientes opciones introduciento la letra A o B, cualquier otra cosa para salir del programa";
	Escribir "Opci�n A : Subcadena de la primera mitad de la frase";
	Escribir "Opci�n B : Subcadena de la segunda mitad de la frase";
	Escribir Sin Saltar "Opci�n? ";
	Leer x;
	Escribir Sin Saltar"Introduce el texto :";
	Leer y;
	//Procedimiento
	Segun x Hacer
		"A":
			z= Subcadena(y,0,Longitud(y)/2);
			Escribir "La primera mitad del texto es: "  ,z;
		"B":
			z= Subcadena(y,(Longitud(y)/2)+1,Longitud(y));
			Escribir "La segunda mitad del texto es: "  ,z;
		De Otro Modo:
			Escribir "Saliste del programa";
	FinSegun
	
FinAlgoritmo
