//El usuario introduce dos n�meros y el programa le dice si los dos son impares o al menos uno es par.
Algoritmo DosNumerosParEImparEj8
	Definir x,y Como Real; //Definici�n de las variables
	//Presentaci�n e introducci�n de los dos n�meros
	Escribir "Introduce dos n�meros y yo te dir� si los dos son impares,o al menos uno es par";
	Escribir Sin Saltar "Primer n�mero: ";
	Leer x;
	Escribir Sin Saltar "Segundo n�mero: ";
	Leer y;
	//Procedimiento
	Si x%2<>0 & y%2<>0 Entonces
		Escribir "Los dos n�meros son impares";
	SiNo
		Escribir "Al menos uno es par";
	FinSi
	
FinAlgoritmo
