//El usuario introduce un n�mero y el programa le dice si es positivo o negativo
Algoritmo PositivoNegativoEj1
	Definir x Como Real;//Definici�n de varable
	//Presentaci�n e introducci�n del n�mero
	Escribir "Introduce un n�mero positivo o negativo";
	Leer x;
	//Procedimiento
	Si x>0 Entonces
		Escribir "Es positivo";
	SiNo
		Escribir "Es negativo";
	FinSi
FinAlgoritmo
