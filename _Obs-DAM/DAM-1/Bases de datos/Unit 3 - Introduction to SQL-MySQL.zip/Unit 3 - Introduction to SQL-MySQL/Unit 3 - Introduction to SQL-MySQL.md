# Unit 3: Introduction to SQL-MySQL

## **3.1. Data Definition Language (DDL)**
A set of statements used to define, modify, and remove the logical structure of a database. It operates on the schema (objects and metadata) and determines how data is organized and stored, rather than manipulating the data itself.

### [[3.1.1. CREATE DATABASE]]
Creates a new database.
```sql
CREATE DATABASE company_db;
```

### [[3.1.2. ALTER DATABASE]]
Modifies database-level properties.
```sql
ALTER DATABASE company_db SET READ_ONLY = OFF;
```

### [[3.1.3. CREATE TABLE]]
Defines a new table structure.
```sql
CREATE TABLE employees (
  id INT PRIMARY KEY,
  name VARCHAR(50)
);
```

### [[3.1.4. ALTER TABLE]]
Modifies an existing table structure.
```sql
ALTER TABLE employees ADD salary DECIMAL(10,2);
```

### [[3.1.5. DROP TABLE]]
Removes a table permanently.
```sql
DROP TABLE employees;
```

### [[3.1.6. CREATE INDEX]]
Creates an index to optimize query performance.
```sql
CREATE INDEX idx_name ON employees(name);
```

### [[3.1.7 DROP INDEX]]
Removes an existing index.
```sql
SELECT * FROM employees
INNER JOIN departments ON employees.dept_id = departments.id;
```

## **3.2. Data Manipulation Language (DML)**
A set of statements used to manage the data contained within a database. It allows inserting, modifying, and deleting existing data inside previously defined structures.

### [[3.2.1. INSERT INTO]]

```sql
INSERT INTO employees (id, name) VALUES (1, 'Alice');
```
### [[3.2.2. UPDATE]]
Modifies existing records.
```sql
UPDATE employees SET name = 'Bob' WHERE id = 1;
```
  
### [[3.2.3. DELETE]]
Removes records.
```sql
DELETE FROM employees WHERE id = 1;
```

## **3.3. Data Query Language (DQL)**
A set of statements focused on data retrieval. It is used to query data, apply filters, sort, group, and present results without modifying the stored data.

### [[3.3.1. SELECT]]
Retrieves data.
```sql
SELECT * FROM employees;
```

### [[3.3.2. SELECT DISTINCT]]
Retrieves unique values.
```sql
SELECT DISTINCT name FROM employees;
```

### [[3.3.3. WHERE]]
Filters records based on conditions.
```sql
SELECT * FROM employees 
WHERE salary > 3000;
```

### [[3.3.4. ORDER BY]]
Sorts results.
```sql
SELECT * FROM employees 
ORDER BY name;
```

### [[3.3.5. LIMIT]]
Restricts the number of returned records.
```sql
SELECT * FROM employees 
LIMIT 5;
```

### [[3.3.6. GROUP BY]]
Groups records for aggregation.
```sql
SELECT department, COUNT(*) FROM employees 
GROUP BY department;
```

### [[3.3.7. HAVING]]
Filters grouped results.
```sql
SELECT department, COUNT(*) FROM employees
GROUP BY department
HAVING COUNT(*) > 5;
```

### [[3.3.8. UNION]]
Combines results from multiple queries.
```sql
SELECT name FROM employees
UNION
SELECT name FROM managers;
```


## **3.4. Operators and conditions**
A collection of logical, relational, and comparison operators used to build conditional expressions. They define selection, combination, and exclusion criteria within queries.

### [[3.4.1. AND]]
Combines conditions that must all be true.
```sql
SELECT * FROM employees 
WHERE salary > 2000 
AND department = 'IT';
```

### [[3.4.2. OR]]
Combines conditions where at least one must be true.
```sql
SELECT * FROM employees 
WHERE department = 'HR' OR department = 'IT';
```

### [[3.4.3. NOT]]
Negates a condition.
```sql
SELECT * FROM employees 
WHERE NOT department = 'HR';
```

### [[3.4.4. IN]]
Checks if a value exists within a set.
```sql
SELECT * FROM employees 
WHERE department IN ('HR', 'IT');
```

### [[3.4.5. BETWEEN]]
Checks if a value falls within a range.
```sql
SELECT * FROM employees 
WHERE salary BETWEEN 2000 AND 4000;
```

### [[3.4.6. LIKE]]
Matches patterns in text.
```sql
SELECT * FROM employees 
WHERE name LIKE 'A%';
```


## **3.5. Aggregate functions**
Functions designed to perform calculations over sets of data. They operate on multiple records to produce a single summarized result, typically in the context of grouped data.

### [[3.5.1. COUNT()]]
Counts records.
```sql
SELECT COUNT(*) FROM employees;
```

### [[3.5.2. AVG()]]
Calculates the average.
```sql
SELECT AVG(salary) FROM employees;
```

### [[3.5.3. SUM()]]
Calculates the total.
```sql
SELECT SUM(salary) FROM employees;
```

### [[3.5.4. MIN()]]
Returns the smallest value.
```sql
SELECT MIN(salary) FROM employees;
```

### [[3.5.5. MAX()]]
Returns the largest value.
```sql
SELECT MAX(salary) FROM employees;
```


## **3.6. Aliases and string functions**
Mechanisms aimed at improving readability and result manipulation. Aliases provide temporary names for expressions or results, while string functions transform and combine textual values.

### [[3.6.1. AS]]
Assigns a temporary name to a column or expression.
```sql
SELECT name AS employee_name FROM employees;
```

### [[3.6.2. CONCAT()]]
Combines multiple text values into one.
```sql
SELECT CONCAT(first_name, ' ', last_name) FROM employees;
```


## **3.7. Joins**
A set of operations used to combine data from multiple related sources. They define how records from different datasets are matched to produce a unified result.

### [[3.7.1. INNER JOIN]]
Returns only matching records.
```sql
SELECT * FROM employees
INNER JOIN departments ON employees.dept_id = departments.id;
```

### [[3.7.2. LEFT (OUTER) JOIN]]
Returns all records from the left source and matching ones from the right.
```sql
SELECT * FROM employees
LEFT JOIN departments ON employees.dept_id = departments.id;
```

### [[3.7.3. RIGHT (OUTER) JOIN]]
Returns all records from the right source and matching ones from the left.
```sql
SELECT * FROM employees
RIGHT JOIN departments ON employees.dept_id = departments.id;
```

### [[3.7.4. CROSS (FULL) JOIN]]
Returns all possible combinations.
```sql
SELECT * FROM employees
CROSS JOIN departments;
```

### [[3.7.5. SELF JOIN]]
Joins a data source with itself.
```sql
SELECT e1.name, e2.name
FROM employees e1
JOIN employees e2 ON e1.manager_id = e2.id;
```
