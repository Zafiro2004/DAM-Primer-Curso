//El usuario introduce un n�mero y el programa le dice si est� entre el 10 y el 20
Algoritmo Rango10a20Ej7
	Definir x Como Entero;//Definici�n de variable
	//Presentaci�n e introducci�n de n�mero
	Escribir Sin Saltar "Introduce un n�mero y te dir� si esta entre el 10 y 20: ";
	Leer x;
	//Procedimiento
	Si x>=10 & x<=20 Entonces
		Escribir "El n�mero esta entre el 10 y el 20";
	SiNo
		Escribir "El n�mero no esta entre el 10 y el 20";
	FinSi
	
FinAlgoritmo
