//El usuario introduce un n�mero y el programa le dice si es divisible entre 3 y 5 o no
Algoritmo Divisible3y5Ej3
	Definir x Como Entero;	//Definici�n de variable
	//Presentaci�n e introducci�n de texto
	Escribir "Introduce un n�mero y yo te dir� si es divisible entre 3 y 5";
	Escribir  Sin Saltar "N�mero? ";
	Leer x;
	//Procedimiento
	Si x%3 =0 & x%5=0 Entonces
		Escribir "El n�mero es divisible entre 3 y 5";
	SiNo
		Escribir "El n�mero no es divisible entre 3 y 5";
	FinSi
FinAlgoritmo
