//El usuario introduce dos n�meros y el programa le dice si el primer n�mero elevado al segundo es mayor que el segundo n�mero elevado al primero
Algoritmo DosNumerosElevadosEj12
	Definir x,y Como Entero; //Definimos dos variables enteras para introducir los dos n�meros
	
	//Presentaci�n e introducci�n de n�meros
	Escribir "Introduce dos n�meros y yo te dir� si el primer n�mero elevado al segundo es mayor que el segundo n�mero elevado al primero";
	Escribir  Sin Saltar "Primer numero: ";
	Leer x;
	Escribir Sin Saltar "Segundo n�mero: ";
	Leer y;
	//Proceso para saber lo que necesitamos
	Si x^y > y^x Entonces
		Escribir "El primer n�mero elevado al segundo ("  ,x^y  ,")  es mayor que el segundo n�mero elevado al primero ( " ,y^x  ,")" ;
	SiNo
		Escribir "El primer n�mero elevado al segundo ("  ,x^y  ,") no es mayor que el segundo n�mero elevado al primero ( " ,y^x ,")";
	FinSi
	
FinAlgoritmo
