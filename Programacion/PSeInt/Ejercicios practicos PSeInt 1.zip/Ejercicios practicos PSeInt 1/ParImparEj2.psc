//El usuario introduce un n�mero y el programa le dice si es par o impar
Algoritmo ParImparEj2
	Definir x como Entero;//Definici�n de variable
	//Presentaci�n e introducci�n de n�mero
	Escribir Sin Saltar "Introduce un n�mero: ";
	Leer x;
	//Procedimiento
	Si x=(x%2) Entonces
		Escribir "El n�mero es par";
	SiNo
		Escribir "El n�mero es impar";
	FinSi
FinAlgoritmo
