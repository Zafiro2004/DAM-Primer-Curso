//El usuario introduce tres n�meros y el programa le dice si el primer n�mero es el mas grande o no
Algoritmo ElMasGrande3NumerosEj11
	Definir x,y,z Como Entero;//Definici�n de variables
	//Presentaci�n e introducci�n de n�meros
	Escribir "Escribe tres n�meros y yo te dir� si el primer n�mero es el mas grande.";
	Escribir Sin Saltar "Primer n�mero :";
	Leer x;
	Escribir  Sin Saltar "Segundo n�mero :";
	Leer y;
	Escribir Sin Saltar "Tercer n�mero: ";
	Leer z;
	//Procedimiento
	Si x>y & x>z Entonces
		Escribir "El primer n�mero es el m�s grande";
	SiNo
		Escribir "El primer n�mero no es el m�s grande";
	FinSi
FinAlgoritmo
