//El usuario introduce dos n�meros y el programa le dice si los dos son positos o al menos uno no es negativo
Algoritmo DosNumerosPositivoNegativoEj5
	Definir x,y Como Real;//Definici�n de variables, reales para aceptar positivos y negativos
	//Presentaci�n e introducci�n de los dos n�meros
	Escribir "Introduce dos n�meros y yo te dir� si los dos son positivos o al menos uno no es positivo";
	Escribir Sin Saltar "Primer n�mero: ";
	Leer x;
	Escribir Sin Saltar "Segundo n�mero: ";
	Leer y;
	//Procedimiento
	Si x>=0 & y>=0 Entonces
		Escribir "Los dos n�meros son positivos";
	SiNo
		Escribir "Al menos uno no es positivo";
	FinSi
FinAlgoritmo
