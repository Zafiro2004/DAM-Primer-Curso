//El usuario introduce dos n�meros y el programa le dice si los dos son positivos o que n�mero es negativo
Algoritmo DosNumerosPositivoNegativoCualNegativoEj6
	Definir x,y Como Real;//Definici�n de variables
	//Presentaci�n e introducci�n de n�meros
	Escribir "Introduce dos n�meros y yo te dir� si los dos son positivos o cual es el negativo";
	Escribir Sin Saltar "Primer n�mero: ";
	Leer x;
	Escribir Sin Saltar "Segundo n�mero: ";
	Leer y;
	//Procedimiento
	Si x>=0 & y>=0 Entonces
		Escribir "Los dos n�meros son positivos";
	SiNo
		Si x<0 Entonces
			Escribir "El n�mero negativo es el primero";
		SiNo
			Escribir "El n�mero negativo es el segundo";
		FinSi
	FinSi
FinAlgoritmo
